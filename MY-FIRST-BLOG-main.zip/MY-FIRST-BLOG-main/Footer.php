<?php
echo'
<footer>
   
</footer>
</body>
</html>
';