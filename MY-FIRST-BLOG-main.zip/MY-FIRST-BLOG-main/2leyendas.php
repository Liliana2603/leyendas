<?php

    include_once "Header.php"; 

?>
<div class="contenedor">

    <br>
    <table>
        <tr>
            <th>
            <div class="card" style="width: 18rem;">
                <img src="BLOG-IMG\juez.jpg" class="card-img-top" alt="...">
                <div class="card-body">
                    <a href="https://leyendasdeelsalvador.com/el-justo-juez-de-la-noche">
                    <h5 class="card-title">El justo juez de la noche</h5>
                    </a>
                   <p class="card-text"></p>
                </div> 
            </div>
            </th>
            <th>
            <div class="card" style="width: 18rem;">
                <img src="BLOG-IMG\duende.jpg" class="card-img-top" alt="...">
                <div class="card-body">
                    <a href="https://leyendasdeelsalvador.com/el-duende">
                    <h5 class="card-title">El Duende</h5>
                    </a>
                   <p class="card-text"></p>
                </div> 
            </div> 
            </th>
        </tr>
        
        <tr>
            <th>
            <div class="card" style="width: 18rem;">
                <img src="BLOG-IMG\novia.jpg" class="card-img-top" alt="...">
                <div class="card-body">
                    <a href="https://leyendasdeelsalvador.com/tenancin-la-novia-del-cipitio">
                    <h5 class="card-title">Tenancín, la novia del Cipitío</h5>
                    </a>
                   <p class="card-text"></p>
                </div> 
            </div>
            </th>
            <th>
            <div class="card" style="width: 18rem;">
                <img src="BLOG-IMG\chancha.jpg" class="card-img-top" alt="...">
                <div class="card-body">
                    <a href="https://leyendasdeelsalvador.com/la-chancha-bruja">
                    <h5 class="card-title">La chancha bruja</h5>
                    </a>
                   <p class="card-text"></p>
                </div> 
            </div> 
            </th>
        </tr>
       
        <tr>
            <th>
            <div class="card" style="width: 18rem;">
                <img src="BLOG-IMG\griton.jpg" class="card-img-top" alt="...">
                <div class="card-body">
                    <a href="https://leyendasdeelsalvador.com/el-griton-de-media-noche">
                    <h5 class="card-title">El Gritón de media noche</h5>
                    </a>
                   <p class="card-text"></p>
                </div> 
            </div>
            </th>
            <th>
            <div class="card" style="width: 18rem;">
                <img src="BLOG-IMG\puerta.jpg" class="card-img-top" alt="...">
                <div class="card-body">
                    <a href="https://leyendasdeelsalvador.com/la-puerta-del-diablo">
                    <h5 class="card-title">La puerta del Diablo</h5>
                    </a>
                   <p class="card-text"></p>
                </div> 
            </div> 
            </th>
        </tr>

        <tr>
            <th>
            <div class="card" style="width: 18rem;">
                <img src="BLOG-IMG\giganta.jpg" class="card-img-top" alt="...">
                <div class="card-body">
                    <a href="https://leyendasdeelsalvador.com/la-giganta-de-jocoro">
                    <h5 class="card-title">La giganta de Jocoro</h5>
                    </a>                    
                   <p class="card-text"></p>
                </div> 
            </div>
            </th>
            <th>
            <div class="card" style="width: 18rem;">
                <img src="BLOG-IMG\mona.jpg" class="card-img-top" alt="...">
                <div class="card-body">
                    <a href="https://leyendasdeelsalvador.com/la-mona-bruja"><h5 class="card-title">La mona bruja</h5></a>
                   <p class="card-text"></p>
                </div> 
            </div> 
            </th>
        </tr>
      
    </table>
    <br><br><br><br><br>
<nav aria-label="Page navigation example">
  <ul class="pagination justify-content-end">
    <li class="page-item ">
    <a class="page-link" href="index.php"><h4><</h4></a>
    </li>
    <li class="page-item"><a class="page-link" href="index.php"><h4>1</h4></a></li>
    <li class="page-item disabled"><a class="page-link" href="2leyendas.php"><h4>2</h4></a></li>
    <li class="page-item disabled">
      <a class="page-link"><h4>></h4></a>
    </li>
  </ul>
</nav>
</div>
<?php
include_once "Footer.php";
?>